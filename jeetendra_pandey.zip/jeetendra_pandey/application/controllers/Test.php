<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

    public function index() {
        $this->load->view('pages/common/header');
        $this->load->view('pages/home');
        $this->load->view('pages/common/footer');
    }

    public function view() {

        $this->load->view('pages/common/header');
        $this->load->view('pages/view');
        $this->load->view('pages/common/footer');
    }

}
